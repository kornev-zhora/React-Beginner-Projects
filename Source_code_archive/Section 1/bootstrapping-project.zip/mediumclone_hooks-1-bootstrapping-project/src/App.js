import React from "react";

function App() {
  return <div className="App">Welcome here is our app</div>;
}

export default App;
